document
  .getElementById("calculator-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    // Obtener los valores de entrada
    let income = document.getElementById("income").value;
    const status = document.getElementById("status").value;
    const dependents = parseInt(document.getElementById("dependents").value);

    // Eliminar comas del ingreso
    income = income.replace(/,/g, "");

    // Convertir el valor de ingreso a número
    income = parseFloat(income);

    let credit = 0;

    // Lógica para calcular el crédito según el estado civil y dependientes
    if (status === "single") {
      if (dependents === 0) {
        if (income >= 18610 && income <= 30240) {
          credit = 1745;
        }
      } else if (dependents === 1) {
        if (income >= 20940 && income <= 36062) {
          credit = 4071;
        }
      } else if (dependents === 2) {
        if (income >= 24430 && income <= 43045) {
          credit = 6400;
        }
      } else if (dependents === 3) {
        if (income >= 24430 && income <= 46537) {
          credit = 7563;
        }
      }
    } else if (status === "married") {
      if (dependents === 0) {
        if (income >= 20940 && income <= 32570) {
          credit = 1745;
        }
      } else if (dependents === 1) {
        if (income >= 25590 && income <= 40712) {
          credit = 4071;
        }
      } else if (dependents === 2) {
        if (income >= 29080 && income <= 47695) {
          credit = 4071;
        }
      } else if (dependents === 3) {
        if (income >= 29080 && income <= 51187) {
          credit = 7563;
        }
      }
    }

    // Si no se cumple el rango de ingresos, no se otorga crédito
    if (credit === 0) {
      document.getElementById("result").textContent =
        "No califica para el crédito con estos valores.";
    } else {
      // Mostrar el resultado con comas usando toLocaleString()
      const formattedIncome = income.toLocaleString();
      const formattedCredit = credit.toLocaleString();
      document.getElementById(
        "result"
      ).textContent = `Crédito por trabajo estimado: $${formattedCredit} para un ingreso de $${formattedIncome}`;
    }
  });
